import React from 'react'

export const Cart = () => {
  return (
    <div>

    </div>
  )
}
export default Cart
