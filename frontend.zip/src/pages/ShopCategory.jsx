import React from 'react'

export const ShopCategory = () => {
  return (
    <div>

    </div>
  )
}
export default ShopCategory